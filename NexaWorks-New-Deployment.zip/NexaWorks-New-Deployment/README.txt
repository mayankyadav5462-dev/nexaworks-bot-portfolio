NexaWorks — New Deployment Package

What is included:
- index.html — complete single-page website
- samples/resume/Mayank_Yadav_ATS_Resume.docx — resume sample
- samples/resume/Mayank_Yadav_Resume_Preview.png — visual resume sample
- samples/project/Minor_Project_Report_Mayank_Portfolio_Copy.docx — privacy-conscious portfolio copy of the minor project report

Website features:
- No public pricing
- WhatsApp CTA using +91 9340566118
- Nexa Assistant FAQ chatbot
- WhatsApp quick-reply template system (copy-to-clipboard)
- Pre-filled WhatsApp enquiry links
- Portfolio sections based on real work
- Responsive mobile layout

Important:
The WhatsApp reply system on a static website provides ready-to-copy replies and pre-filled WhatsApp messages. True automatic replies to incoming WhatsApp messages require WhatsApp Business/API automation and cannot be performed by a plain static HTML site alone.

Deployment:
Upload the CONTENTS of this folder to GitHub, with index.html at the repository root and the samples folder alongside it. Then deploy the repository on Vercel.
